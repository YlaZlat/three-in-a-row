const BusterProtoController = require('BusterProtoController');
const Model = require('HammerBusterModel');
const Viev = require('HammerBusterViev');

cc.Class({
        extends: BusterProtoController,
    properties: {

        viev: {
            default: null,
            type: Viev,
            override: true
        },
        
    },  

    onLoad () {
        this._super();
        this.model = new Model(this, this.viev);
        this.model.init();
        this.hummer = null;
        this.fieldNode = this.viev.fieldNode;

    },

    init(){
        this.model.init();
    },

    onBusterClick(){
        if(!this.game.state.game) return; 
        if(this.model.getHummer()) {
            this.offStandartGameEvents();
            this.canvas.on(this.mousemove, this.onMouseMove, this);
            this.fieldNode.on(this.mousedown, this.onFieldMouseDown, this);
        }
    },

    onMouseMove(event){
        let pos = this.node.convertToNodeSpaceAR(event.getLocation());
        this.model.hummer.setPosition(pos);
    },

    onFieldMouseDown(event){
        if(event.target === event.currentTarget) return;
        this.canvas.off(this.mousemove, this.onMouseMove, this);
        this.fieldNode.off(this.mousedown, this.onFieldMouseDown, this);
        event.stopPropagation();
        let target = event.target;
        this.model.onFieldHummerDown(target)
            .then (()=> {
                this.onStandartGameEvents();
            })  
    },

    
});

