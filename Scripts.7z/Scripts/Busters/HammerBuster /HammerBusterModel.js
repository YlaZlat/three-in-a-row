const BusterProtoModel = require('BusterProtoModel');

const BusterHummerModel = cc.Class({
    extends: BusterProtoModel,
    
    ctor: function (controller, viev) {
        this.viev = viev;
        this.controller = controller;
        this.passingModel= this.controller.passingModel;
        this.fieldActions = this.controller.fieldActions;
        this.hammer;
        this.num = 3;
    },

    getHummer(){
        if(this.num < 1) return;
        this.num--;
        this.viev.displayNum(this.num);
        this.hummer = this.viev.spawnHummer();
        return this.hummer;
    },

    despawnHummer(){
        this.viev.despawnHummer(this.hummer);
        this.hummer = null;
    },

    onFieldHummerDown(sprite){
        return  new Promise((resolve) => {
            this.despawnHummer();
            this.fieldActions.despawnSprites([sprite]);
            const dumpingDelay = 500;
            this.rebuildField = this.fieldActions.rebuildField.bind(this.fieldActions);
            setTimeout(()=> {
                this.rebuildField()
                .then (() => {
                    return this.fieldActions.handleMatchesAfterRebuild()
                })
                .then (() => { resolve();})  
                
            }, dumpingDelay);
        })
    },

});

module.exports = BusterHummerModel;