const BusterProtoViev = require('BusterProtoViev');

cc.Class({
    extends: BusterProtoViev ,

    properties: {

        numLabel: {
            default: null,
            type: cc.Label,
            override: true
        },

        hummerLabel:{
            default: null,
            type: cc.Node
        },

        hummerPrefab: {
            default: null,
            type: cc.Prefab
        }, 


        fieldNode: 
        {
            default: null,
            type: cc.Node
        },  

    },

    onLoad(){
        this.hummerPool = new cc.NodePool();
        const hummer = cc.instantiate(this.hummerPrefab); // create node instance
        this.hummerPool.put(hummer); // populate your pool with put method

    },


    spawnHummer(){
        const hummer = this.hummerPool.get(this);
        this.node.addChild(hummer);
        hummer.zIndex = 500;
        hummer.position = this.hummerLabel.position;
        return hummer;
    },

    despawnHummer (hummer) {
        this.hummerPool.put(hummer);
    },


});

